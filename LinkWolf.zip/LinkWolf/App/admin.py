from django.contrib import admin
from App.models import Usuario,Grupo
# Register your models here.

admin.site.register(Usuario)
admin.site.register(Grupo)