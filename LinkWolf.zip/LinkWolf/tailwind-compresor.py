from bs4 import BeautifulSoup
import cssutils
import argparse

# Creamos un objeto ArgumentParser para definir los argumentos que queremos recibir
parser = argparse.ArgumentParser(description="Genera un archivo css con los estilos aplicables a un documento html")


# Añadimos los argumentos que esperamos recibir
parser.add_argument("html_path", help="El path del documento html")
parser.add_argument("css_path", help="El path del documento css")
parser.add_argument("output_name", help="El nombre del archivo css de salida")


# Obtenemos los argumentos que se pasan al ejecutar el programa
args = parser.parse_args()


# Leemos el texto del documento html y el texto del archivo css desde los paths especificados
with open(args.html_path, "r") as html_file:
  html_text = html_file.read()

with open(args.css_path, "r") as css_file:
  css_text = css_file.read()


# El resto del código es igual al anterior
soup = BeautifulSoup(html_text, "html.parser")
css = cssutils.parseString(css_text, remove_unused_keyframes=True, remove_unused_fontface=True, remove_unused_variables=True, remove_comments=True)
selectors = {}

for rule in css:
  if rule.type == rule.STYLE_RULE:
    selector = rule.selectorText
    style = rule.style.cssText
    elements = soup.select(selector)
    if elements:
      selectors[selector] = style

# En lugar de imprimir el diccionario de selectores y estilos, lo guardamos en un archivo con el nombre especificado
with open(args.output_name, "w") as output_file:
  for selector, style in selectors.items():
    output_file.write(f"{selector} {{\n{style}\n}}\n")
